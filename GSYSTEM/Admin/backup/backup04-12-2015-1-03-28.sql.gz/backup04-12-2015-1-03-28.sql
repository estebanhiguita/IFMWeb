-- ---------------------------------------------------------
  --
  -- SIMPLE SQL Dump
  -- 
  -- http://www.nawa.me/
  --
  -- Host Connection Info: Localhost via UNIX socket
  -- Generation Time: December 04, 2015 at 01:03 AM ( Europe/Berlin )
  -- Server version: 5.6.25
  -- PHP Version: 5.6.11
  --
  -- ---------------------------------------------------------



  SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
  SET time_zone = "+00:00";


  /*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
  /*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
  /*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
  /*!40101 SET NAMES utf8 */;
  

          -- ---------------------------------------------------------
          --
          -- Table structure for table : `tbl_contacto`
          --
          -- ---------------------------------------------------------

          CREATE TABLE `tbl_contacto` (
  `id_contacto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(70) NOT NULL,
  `email` varchar(65) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` bit(1) NOT NULL DEFAULT b'1',
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_contacto`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

          --
          -- Dumping data for table `tbl_contacto`
          --

          INSERT INTO `tbl_contacto` (`id_contacto`, `nombre`, `email`, `telefono`, `descripcion`, `estado`, `fecha`) VALUES
(1, 'Yhoan Andres Galeano', 'yhoangaleano@gmail.com', 3218517452, 'Probando los comentarios', 1, '2015-06-16 10:02:20');



          -- ---------------------------------------------------------
          --
          -- Table structure for table : `tbl_expertos`
          --
          -- ---------------------------------------------------------

          CREATE TABLE `tbl_expertos` (
  `id_expertos` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `url` varchar(100) NOT NULL,
  `profesion` varchar(100) NOT NULL,
  `cargo` varchar(100) NOT NULL,
  `estado` int(20) DEFAULT '0',
  PRIMARY KEY (`id_expertos`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

          --
          -- Dumping data for table `tbl_expertos`
          --

          INSERT INTO `tbl_expertos` (`id_expertos`, `nombre`, `url`, `profesion`, `cargo`, `estado`) VALUES
(26, 'C�sar Mauricio Vel�squez Ossa ', '2.jpg', 'Doctor en Comunicaci�n ', 'CONSULTOR EN COMUNICACI�N ESTRAT�GICA', 1),
(25, 'Alex Penagos Hincapi�', 'alex.jpg', 'Publicista', 'CONSULTOR EN MARKETING Y PUBLICIDAD', 1),
(22, 'Federico', '2 Federico blanco.jpg', 'Hoyos', 'Doctor', 0),
(23, 'Roberto Rave R�os', 'robertrave.jpg', 'Posgrado Comercio Exterior ', 'CONSULTOR EN MARKETING POL�TICO', 1),
(28, 'Juliana Londo�o Barrera ', '6 Julianablanco.jpg', 'Magister en Comunicaci�n  ', 'CONSULTOR EN COMUNICACI�N DIGITAL', 1),
(27, 'Claudia Bustamante', 'CLAUDIA BUSTAMANTE.jpg', ' Magister en Estudios Pol�ticos  ', 'CONSULTOR EN MARKETING POL�TICO DIGITAL', 1),
(24, 'Jaime Humberto Tob�n Correa ', '3 Jaime.jpg', 'Doctorando en RRII Iberoamericanas ', ' CONSULTOR EN PRENSA Y COMUNICACI�N CORPORAL', 1),
(21, 'Jos� Ignacio Penagos Hincapi�', 'jose.jpg', 'PhD en Comunicaci�n', 'Director General y Consultor en Comunicaci�n', 0),
(29, 'Andr�s Felipe Giraldo D�vila ', '4 Andres.jpg', 'Magister en Comunicaci�n  ', 'CONSULTOR EN GEOPOL�TICA', 1),
(30, 'Giovany Pineda Gallego ', 'bark.jpg', 'Comunicador Gr�fico Publicitario  ', 'MEDIOS AUDIOVISUALES', 1),
(31, 'Andr�s Ca�ola Garc�a ', 'ykim.jpg', 'Comunicador y Relacionista Corporativo  ', 'COMUNICACI�N CORPORATIVA', 1),
(32, 'Esteban Higuita Garc�a ', 'EST.jpg', 'Ingeniero Matem�tico  ', 'PROGRAMADOR DE APLICACIONES', 1);



          -- ---------------------------------------------------------
          --
          -- Table structure for table : `tbl_niff`
          --
          -- ---------------------------------------------------------

          CREATE TABLE `tbl_niff` (
  `id_niff` int(11) NOT NULL AUTO_INCREMENT,
  `url_imagen` varchar(100) NOT NULL,
  `estado` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id_niff`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

          --
          -- Dumping data for table `tbl_niff`
          --

          INSERT INTO `tbl_niff` (`id_niff`, `url_imagen`, `estado`) VALUES
(1, 'Niff1.JPG', 1);



          -- ---------------------------------------------------------
          --
          -- Table structure for table : `tbl_noticia`
          --
          -- ---------------------------------------------------------

          CREATE TABLE `tbl_noticia` (
  `id_noticia` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `url_imagen` varchar(100) NOT NULL,
  `url_icono` varchar(100) NOT NULL,
  PRIMARY KEY (`id_noticia`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

          --
          -- Dumping data for table `tbl_noticia`
          --

          INSERT INTO `tbl_noticia` (`id_noticia`, `titulo`, `descripcion`, `url_imagen`, `url_icono`) VALUES
(1, 'El Equipo Ideal ', 'Encuentra con nosotros el equipo ideal. ', 'BarraDeNoticias2.jpg', 'http://www.gestionsystem.com.co/ComercialVentas.html'),
(3, 'GS DIGITAL MARKETING', 'MUY PRONTO GS DIGITAL MARKETING', 'BarraDeNoticias1.JPG', 'https://www.facebook.com/gestionsystem?ref=hl');



          -- ---------------------------------------------------------
          --
          -- Table structure for table : `tbl_partner`
          --
          -- ---------------------------------------------------------

          CREATE TABLE `tbl_partner` (
  `id_partner` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `url_imagen` varchar(100) NOT NULL,
  `estado` bit(1) NOT NULL,
  PRIMARY KEY (`id_partner`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

          --
          -- Dumping data for table `tbl_partner`
          --

          INSERT INTO `tbl_partner` (`id_partner`, `nombre`, `url_imagen`, `estado`) VALUES
(36, 'PELDAR', 'peldar.jpg', 1),
(2, 'Ofimaticarte', 'Ofim�tica.png', 0),
(3, 'Microsoft', 'Microsoft.PNG', 0),
(4, 'Adobe ', 'Adobe.png', 0),
(5, 'Apple ', 'apple.png', 0),
(35, 'TELEVIDEO', 'televideo.jpg', 1),
(33, 'FENACON', 'fenacol.jpg', 1),
(34, 'MOVIERECORD', 'movierecord.jpg', 1);



          -- ---------------------------------------------------------
          --
          -- Table structure for table : `tbl_persona`
          --
          -- ---------------------------------------------------------

          CREATE TABLE `tbl_persona` (
  `id_persona` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `usuario` varchar(45) NOT NULL,
  `clave` varchar(45) NOT NULL,
  PRIMARY KEY (`id_persona`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

          --
          -- Dumping data for table `tbl_persona`
          --

          INSERT INTO `tbl_persona` (`id_persona`, `nombre`, `usuario`, `clave`) VALUES
(1, 'gsystem', 'usuario_gs', 'g35t1on2015!');



          -- ---------------------------------------------------------
          --
          -- Table structure for table : `tbl_slide`
          --
          -- ---------------------------------------------------------

          CREATE TABLE `tbl_slide` (
  `id_slide` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_imagen` varchar(45) NOT NULL,
  `url_imagen` varchar(100) NOT NULL,
  `url` varchar(205) NOT NULL,
  `estado` bit(1) NOT NULL,
  `tbl_unidad_negocio_id_unidad_negocio` int(11) NOT NULL,
  PRIMARY KEY (`id_slide`),
  KEY `fk_tbl_slide_tbl_unidad_negocio1_idx` (`tbl_unidad_negocio_id_unidad_negocio`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

          --
          -- Dumping data for table `tbl_slide`
          --

          INSERT INTO `tbl_slide` (`id_slide`, `nombre_imagen`, `url_imagen`, `url`, `estado`, `tbl_unidad_negocio_id_unidad_negocio`) VALUES
(1, 'Slider1.jpg', '/1/Slider1.jpg', 'http://gestionsystem.com.co/index.html', 1, 1),
(2, 'Slider2.jpg', '/1/Slider2.jpg', 'http://gestionsystem.com.co/index.html', 1, 1),
(3, 'Slider3.jpg', '/1/Slider3.jpg', 'http://gestionsystem.com.co/index.html', 1, 1),
(4, 'Slider4.jpg', '/1/Slider4.jpg', 'http://gestionsystem.com.co/index.html', 1, 1),
(35, 'slider5.JPG', '/1/slider5.JPG', 'http://gestionsystem.com.co/ComercialVentas.html', 1, 1),
(6, 'SliderCasosExito1.jpg', '/2/SliderCasosExito1.jpg', 'http://gestionsystem.com.co/index.html', 1, 2),
(7, 'SliderCasosExito2.jpg', '/2/SliderCasosExito2.jpg', 'http://gestionsystem.com.co/index.html', 1, 2),
(8, 'Imagenfondo4.jpg', '/8/Imagenfondo4.jpg', 'http://gestionsystem.com.co/nosotros.html', 1, 8),
(9, 'Imagenfondo2.jpg', '/8/Imagenfondo2.jpg', 'http://gestionsystem.com.co/nosotros.html', 1, 8),
(10, 'Imagenfondo3.jpg', '/8/Imagenfondo3.jpg', 'http://gestionsystem.com.co/nosotros.html', 1, 8),
(11, 'Consultoria1.jpg', '/4/Consultoria1.jpg', 'http://gestionsystem.com.co/index.html', 1, 4),
(12, 'Consultoria2.jpg', '/4/Consultoria2.jpg', 'http://gestionsystem.com.co/index.html', 1, 4),
(13, 'ImagenFondo4.jpg', '/6/ImagenFondo4.jpg', 'http://gestionsystem.com.co/index.html', 1, 6),
(14, 'ImagenFondo5.jpg', '/6/ImagenFondo5.jpg', 'http://gestionsystem.com.co/index.html', 1, 6),
(15, 'ComercialOfimatica1.JPG', '/3/ComercialOfimatica1.JPG', 'http://gestionsystem.com.co/index.html', 1, 3),
(16, 'Consultoria1.jpg', '/3/Consultoria1.jpg', 'http://gestionsystem.com.co/comercialOfimatica.html', 1, 3),
(17, 'Formacion2.jpg', '/5/Formacion2.jpg', 'http://gestionsystem.com.co/formacion.html', 1, 5),
(30, 'SliderSoporte.jpg', '/7/SliderSoporte.jpg', 'http://gestionsystem.com.co/soporte.html', 1, 7),
(19, 'slider.JPG', '/9/slider.JPG', 'http://gestionsystem.com.co/ComercialVentas.html', 1, 9),
(38, 'Ultrabook.jpg', '/9/Ultrabook.jpg', 'http://gestionsystem.com.co/ComercialVentas.html', 1, 9),
(22, 'slider3.jpg', '/9/slider3.jpg', 'http://gestionsystem.com.co/ComercialVentas.html', 1, 9),
(25, 'slider4.JPG', '/9/slider4.JPG', 'http://gestionsystem.com.co/ComercialVentas.html', 1, 9),
(27, 'ComercialOfimatica2.JPG', '/3/ComercialOfimatica2.JPG', 'http://gestionsystem.com.co/comercialOfimatica.html', 1, 3),
(29, '2.JPG', '/5/2.JPG', 'http://gestionsystem.com.co/formacion.html', 1, 5),
(31, 'SliderSoporte2.jpg', '/7/SliderSoporte2.jpg', 'http://gestionsystem.com.co/soporte.html', 1, 7),
(32, 'SliderSoporte3.jpg', '/7/SliderSoporte3.jpg', 'http://gestionsystem.com.co/soporte.html', 1, 7),
(33, 'SliderSoporte4.jpg', '/7/SliderSoporte4.jpg', 'http://gestionsystem.com.co/soporte.html', 1, 7),
(34, 'RackALaMedida.jpg', '/9/RackALaMedida.jpg', 'http://gestionsystem.com.co/ComercialVentas.html', 1, 9),
(37, 'Software.JPG', '/9/Software.JPG', 'http://gestionsystem.com.co/ComercialVentas.html', 1, 9);



          -- ---------------------------------------------------------
          --
          -- Table structure for table : `tbl_unidad_negocio`
          --
          -- ---------------------------------------------------------

          CREATE TABLE `tbl_unidad_negocio` (
  `id_unidad_negocio` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) NOT NULL,
  `url_logo` varchar(100) NOT NULL,
  `url_imagen` varchar(200) NOT NULL,
  `descripcion` longtext,
  PRIMARY KEY (`id_unidad_negocio`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

          --
          -- Dumping data for table `tbl_unidad_negocio`
          --

          INSERT INTO `tbl_unidad_negocio` (`id_unidad_negocio`, `nombre`, `url_logo`, `url_imagen`, `descripcion`) VALUES
(1, 'Comunicaci�n Corporativa', 'corporativo.png', 'infoCorporativo.png', 'Entendemos la Comunicaci�n Corporativa como el elemento fundamental de una organizaci�n para establecer v�nculos con sus p�blicos. Por eso trabajamos la comunicaci�n para crear y transmitir mensajes claros y que sean atractivos, a partir de estrategias innovadoras que integren diversas miradas y herramientas comunicativas vinculadas a las particularidades de cada organizaci�n en el relacionamiento con sus p�blicos.'),
(2, 'Comunicaci�n Digital', 'digital.png', 'infoDigital.png', 'Trabajamos la Comunicaci�n Digital a partir de la planeaci�n, dise�o y construcci�n de estrategias con resultados que alcancen los objetivos establecidos. Sabemos que para que el mensaje organizacional pueda llegar a las audiencias adecuadas, deben usarse las herramientas digitales adecuadas logrando as� el m�ximo impacto y un mayor alcance de una organizaci�n en las distintas plataformas digitales.'),
(3, 'Comunicaci�n Audiovisual', 'audiovisual.png', 'infoAudiovisual.png', 'Utilizamos la Comunicaci�n Audiovisual para despertar el inter�s y facilitar la comprensi�n de cualquier mensaje en los p�blicos de una organizaci�n. Presentamos temas de distinta complejidad de forma simple y llamativa a trav�s de distintos formatos audiovisuales, encarg�ndonos de la concepci�n creativa y del proceso de: preproducci�n, producci�n y postproducci�n; con el prop�sito de mostrar las ideas de una manera mucho m�s interesante.');



  -- FORANEAS

  ALTER TABLE `tbl_expertos`
  ADD CONSTRAINT `fk_tbl_expertos_tbl_unidad_negocio` FOREIGN KEY (`tbl_unidad_negocio_id_unidad_negocio`) REFERENCES `tbl_unidad_negocio` (`id_unidad_negocio`) ON DELETE NO ACTION ON UPDATE NO ACTION;

  --
  -- Filtros para la tabla `tbl_galeria`
  --
  ALTER TABLE `tbl_galeria`
  ADD CONSTRAINT `fk_tbl_galeria_tbl_producto1` FOREIGN KEY (`tbl_producto_id_producto`) REFERENCES `tbl_producto` (`id_producto`) ON DELETE NO ACTION ON UPDATE NO ACTION;

  --
  -- Filtros para la tabla `tbl_producto`
  --
  ALTER TABLE `tbl_producto`
  ADD CONSTRAINT `fk_tbl_producto_tbl_marca` FOREIGN KEY (`tbl_marca_id_marca`) REFERENCES `tbl_marca` (`id_marca`) ON DELETE NO ACTION ON UPDATE NO ACTION;

  --
  -- Filtros para la tabla `tbl_slide`
  --
  ALTER TABLE `tbl_slide`
  ADD CONSTRAINT `fk_tbl_slide_tbl_unidad_negocio1` FOREIGN KEY (`tbl_unidad_negocio_id_unidad_negocio`) REFERENCES `tbl_unidad_negocio` (`id_unidad_negocio`) ON DELETE NO ACTION ON UPDATE NO ACTION;


  /*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
  /*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
  /*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;